# qBittorrent Icons

## Color Reference
It is recommended to use color from the following source: [Primer primitives colors](https://primer.style/primitives/colors).

More information: https://primer.style/design/foundations/color
