# Program to find the square root
num = float(input("Enter a number: "))
sqrt = num**0.5
print("The square root of", num, "is:", sqrt)
