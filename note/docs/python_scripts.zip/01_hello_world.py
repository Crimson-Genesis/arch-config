# Program to print Hello, World!
print("Hello, World!")
